CH 701 airplane by macflaille on Thingiverse: https://www.thingiverse.com/thing:435372

Summary:
It's a very known STOL airplane designed by Chris Heintz. A lot of CH 701 are flying across the world.